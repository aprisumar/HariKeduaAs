=================[ REVERSE ENGINERING ]=================
@ Create bY Johny a.k.a PETR03X, Fri,06/07/2019
@ Thank To all or other member N45HT
@ Special thank's to ShinChan, Api Rahmon, ZulFansat, and you!
========================[ ABOUT ]========================
['arch'] => ARM
['bits'] => 32
['compiler'] => Android (5058415 based on r339409)
['crypto'] => false
['intrp'] => /system/bin/linker
['machine'] => ARM
['os'] => Android
========================[ RULES ]========================
[1] => Cari Flag pada source yang sudah di sediakan!
[2] => semuah cara di perbolehkan untuk mendapatkan flag!
[3] => waktu akan terus berjalan sampai flag tersubmit!
[4] => GoodLuck!
========================[ CLUEE ]========================
['1'] => Jump address